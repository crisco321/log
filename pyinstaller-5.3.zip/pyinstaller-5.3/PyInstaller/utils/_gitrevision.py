#
# The content of this file will be filled in with meaningful data when creating an archive using `git archive` or by
# downloading an archive from github, e.g., from github.com/.../archive/develop.zip
#
rev = "fbf7948be8"  # abbreviated commit hash
commit = "fbf7948be85177dd44b41217e9f039e1d176de6b"  # commit hash
date = "2022-07-30 20:57:51 +0100"  # commit date
author = "Brénainn Woodsend <bwoodsend@gmail.com>"
ref_names = "tag: v5.3"  # incl. current branch
commit_message = """Release 5.3.
"""
